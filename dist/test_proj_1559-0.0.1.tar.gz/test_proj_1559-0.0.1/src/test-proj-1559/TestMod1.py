def test():
    print("Good to go.")